from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash
import os
import uuid
import subprocess
import zipfile
import re
import json
from datetime import datetime
from openpyxl import load_workbook


app = Flask(__name__)
app.secret_key = "secret-key"  # Needed for flash messages

# Directory setup
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
DATA_FILE = os.path.join(BASE_DIR, "tenders.json")

os.makedirs(UPLOAD_DIR, exist_ok=True)

# Load stored tenders if any
if os.path.exists(DATA_FILE):
    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        tenders = json.load(f)
else:
    tenders = {}


def save_tenders():
    """Persist tender data to disk."""
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(tenders, f, ensure_ascii=False, indent=2)


def extract_text_from_pdf(path: str) -> str:
    """Extract text from a PDF file using pdftotext command-line tool."""
    # pdftotext writes to stdout when output file is -
    try:
        result = subprocess.run(['pdftotext', '-layout', path, '-'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        return result.stdout.decode('utf-8', errors='ignore')
    except Exception as e:
        print(f"PDF extraction failed: {e}")
        return ""


def extract_text_from_docx(path: str) -> str:
    """Extract text from a docx file by reading its XML content."""
    try:
        text = []
        with zipfile.ZipFile(path) as docx_zip:
            with docx_zip.open('word/document.xml') as document_xml:
                xml = document_xml.read().decode('utf-8', errors='ignore')
                # Remove XML tags
                cleaned = re.sub(r'<[^>]+>', '', xml)
                text.append(cleaned)
        return '\n'.join(text)
    except Exception as e:
        print(f"DOCX extraction failed: {e}")
        return ""


def parse_xlsx(path: str):
    """Parse an xlsx file and return a list of rows (first sheet)."""
    rows = []
    try:
        wb = load_workbook(filename=path, data_only=True)
        sheet = wb.active
        for row in sheet.iter_rows(values_only=True):
            # Convert each cell to string if not None
            rows.append([str(cell) if cell is not None else '' for cell in row])
    except Exception as e:
        print(f"XLSX parsing failed: {e}")
    return rows


def simple_summary(text: str) -> str:
    """Generate a simple summary by taking the first few sentences."""
    # Split by sentences
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    summary_sentences = sentences[:3]  # first 3 sentences
    return ' '.join(summary_sentences)


def extract_fields(text: str) -> dict:
    """Extract simple fields like EMD and due date using regex heuristics."""
    fields = {}
    # EMD pattern: look for ₹ or Rs or rupees followed by numbers
    emd_match = re.search(r'(?:EMD|Earnest Money Deposit).*?(₹|Rs\.?|INR)\s*([\d,\.]+)', text, re.IGNORECASE)
    if emd_match:
        fields['emd'] = f"{emd_match.group(1)} {emd_match.group(2)}"
    else:
        # fallback: look for any currency pattern
        general_match = re.search(r'(₹|Rs\.?|INR)\s*([\d,\.]+)', text)
        fields['emd'] = f"{general_match.group(1)} {general_match.group(2)}" if general_match else ''
    # Due date pattern: look for a date format (dd/mm/yyyy or dd-mm-yyyy)
    date_match = re.search(r'(?:submission(?: date)?|due date|closing date)[^\d]*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})', text, re.IGNORECASE)
    if date_match:
        fields['due_date'] = date_match.group(1)
    else:
        # fallback: first date pattern found
        generic_date = re.search(r'\d{1,2}[/-]\d{1,2}[/-]\d{2,4}', text)
        fields['due_date'] = generic_date.group(0) if generic_date else ''
    # Eligibility: take first 200 characters of text as placeholder
    fields['eligibility'] = text[:200] + '...' if len(text) > 200 else text
    return fields


def process_file(file_storage) -> dict:
    """Process an uploaded file and return tender data."""
    filename = file_storage.filename
    file_id = str(uuid.uuid4())
    save_path = os.path.join(UPLOAD_DIR, file_id + '_' + filename)
    file_storage.save(save_path)

    ext = filename.lower().split('.')[-1]
    text = ''
    table_rows = []
    if ext in ['pdf']:
        text = extract_text_from_pdf(save_path)
    elif ext in ['docx']:
        text = extract_text_from_docx(save_path)
    elif ext in ['xlsx', 'xls']:
        table_rows = parse_xlsx(save_path)
    else:
        text = ''

    # If xlsx, we still want some text summarization (maybe from first few rows)
    if not text and table_rows:
        # Flatten first 5 rows into a string
        flat = '\n'.join([', '.join(row) for row in table_rows[:5]])
        text = flat

    summary = simple_summary(text) if text else ''
    fields = extract_fields(text) if text else {'emd': '', 'due_date': '', 'eligibility': ''}

    tender = {
        'id': file_id,
        'filename': filename,
        'path': save_path,
        'text': text,
        'table_rows': table_rows,
        'summary': summary,
        'emd': fields.get('emd', ''),
        'due_date': fields.get('due_date', ''),
        'eligibility': fields.get('eligibility', ''),
        'uploaded_at': datetime.now().isoformat()
    }
    tenders[file_id] = tender
    save_tenders()
    return tender


@app.route('/')
def index():
    # Sort tenders by date uploaded desc
    tender_list = sorted(tenders.values(), key=lambda x: x['uploaded_at'], reverse=True)
    return render_template('index.html', tenders=tender_list)


@app.route('/upload', methods=['POST'])
def upload():
    if 'files' not in request.files:
        flash('No file part in the request')
        return redirect(url_for('index'))
    files = request.files.getlist('files')
    if not files or files[0].filename == '':
        flash('No files selected')
        return redirect(url_for('index'))
    for f in files:
        process_file(f)
    flash(f"Uploaded {len(files)} file(s) successfully!")
    return redirect(url_for('index'))


@app.route('/tender/<tid>')
def tender_detail(tid):
    tender = tenders.get(tid)
    if not tender:
        flash('Tender not found')
        return redirect(url_for('index'))
    return render_template('detail.html', tender=tender)


@app.route('/download/<tid>')
def download(tid):
    tender = tenders.get(tid)
    if not tender:
        flash('Tender not found')
        return redirect(url_for('index'))
    directory = os.path.dirname(tender['path'])
    filename = os.path.basename(tender['path'])
    return send_from_directory(directory, filename, as_attachment=True)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
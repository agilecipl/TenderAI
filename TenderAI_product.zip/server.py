#!/usr/bin/env python3

"""
Simple TenderAI HTTP server using only Python standard library. Handles
uploading tender documents (PDF, DOCX, XLSX), extracts basic data,
stores tender information, and serves a dashboard plus detail pages.

This server is designed for demonstration purposes. It uses cgi.FieldStorage
to parse multipart form uploads and does not depend on external
libraries beyond openpyxl for XLSX parsing and the system utility
`pdftotext` for PDF extraction.
"""

from http.server import BaseHTTPRequestHandler, HTTPServer
import cgi
import os
import uuid
import subprocess
import zipfile
import re
import json
from datetime import datetime
from urllib.parse import unquote
from openpyxl import load_workbook

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
DATA_FILE = os.path.join(BASE_DIR, "tenders.json")
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")
STATIC_DIR = os.path.join(BASE_DIR, "static")

os.makedirs(UPLOAD_DIR, exist_ok=True)

# Load existing tenders
if os.path.exists(DATA_FILE):
    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        TENDERS = json.load(f)
else:
    TENDERS = {}


def save_tenders():
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(TENDERS, f, ensure_ascii=False, indent=2)


def extract_text_from_pdf(path: str) -> str:
    try:
        result = subprocess.run(['pdftotext', '-layout', path, '-'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        return result.stdout.decode('utf-8', errors='ignore')
    except Exception as e:
        print(f"PDF extraction failed for {path}: {e}")
        return ""


def extract_text_from_docx(path: str) -> str:
    try:
        with zipfile.ZipFile(path) as docx_zip:
            with docx_zip.open('word/document.xml') as document_xml:
                xml = document_xml.read().decode('utf-8', errors='ignore')
                cleaned = re.sub(r'<[^>]+>', '', xml)
        return cleaned
    except Exception as e:
        print(f"DOCX extraction failed for {path}: {e}")
        return ""


def parse_xlsx(path: str):
    rows = []
    try:
        wb = load_workbook(filename=path, data_only=True)
        sheet = wb.active
        for row in sheet.iter_rows(values_only=True):
            rows.append([str(cell) if cell is not None else '' for cell in row])
    except Exception as e:
        print(f"XLSX parsing failed for {path}: {e}")
    return rows


def simple_summary(text: str) -> str:
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    return ' '.join(sentences[:3])


def extract_fields(text: str) -> dict:
    fields = {}
    emd_match = re.search(r'(?:EMD|Earnest Money Deposit).*?(₹|Rs\.?|INR)\s*([\d,\.]+)', text, re.IGNORECASE)
    if emd_match:
        fields['emd'] = f"{emd_match.group(1)} {emd_match.group(2)}"
    else:
        general_match = re.search(r'(₹|Rs\.?|INR)\s*([\d,\.]+)', text)
        fields['emd'] = f"{general_match.group(1)} {general_match.group(2)}" if general_match else ''
    date_match = re.search(r'(?:submission(?: date)?|due date|closing date)[^\d]*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})', text, re.IGNORECASE)
    if date_match:
        fields['due_date'] = date_match.group(1)
    else:
        generic_date = re.search(r'\d{1,2}[/-]\d{1,2}[/-]\d{2,4}', text)
        fields['due_date'] = generic_date.group(0) if generic_date else ''
    fields['eligibility'] = text[:200] + '...' if len(text) > 200 else text
    return fields


def render_template(name: str, **context) -> str:
    """Render a template by formatting placeholders with context."""
    path = os.path.join(TEMPLATES_DIR, name)
    with open(path, 'r', encoding='utf-8') as f:
        tpl = f.read()
    # Simple replacement: {{ key }} replaced with context value
    for key, value in context.items():
        # Convert value to string for rendering; handle special cases later
        tpl = tpl.replace('{{ ' + key + ' }}', str(value))
    return tpl


class TenderAIHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = unquote(self.path)
        if path == '/' or path.startswith('/index'):
            self.handle_index()
        elif path.startswith('/tender/'):
            parts = path.split('/')
            tid = parts[2] if len(parts) > 2 else ''
            self.handle_detail(tid)
        elif path.startswith('/download/'):
            tid = path.split('/')[-1]
            self.handle_download(tid)
        elif path.startswith('/static/'):
            # Serve static assets
            self.serve_static(path[len('/static/'):])
        else:
            self.send_error(404, "Not Found")

    def do_POST(self):
        path = unquote(self.path)
        if path == '/upload':
            self.handle_upload()
        else:
            self.send_error(404, "Not Found")

    def handle_index(self):
        # Parse query string for flash message
        from urllib.parse import urlparse, parse_qs
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        msg = query.get('msg', [''])[0]
        # Build table rows HTML manually
        tender_list = sorted(TENDERS.values(), key=lambda x: x['uploaded_at'], reverse=True)
        rows_html = ''
        for i, tender in enumerate(tender_list, 1):
            emd = tender.get('emd') or '—'
            due = tender.get('due_date') or '—'
            summary = tender.get('summary') or 'No summary'
            rows_html += f"<tr><td>{i}</td><td>{tender['filename']}</td><td>{emd}</td><td>{due}</td><td>{summary}</td><td><a href='/tender/{tender['id']}'>View</a> | <a href='/download/{tender['id']}'>Download</a></td></tr>"
        # Render template
        html = render_template('index.html', dummy='')
        html = html.replace('<!--TABLE_ROWS-->', rows_html)
        html = html.replace('{{ year }}', str(datetime.utcnow().year))
        # Insert flash message if present
        if msg:
            flash_html = f"<ul class='flash-messages'><li>{msg}</li></ul>"
            html = html.replace('<div id="flash"></div>', flash_html)
        else:
            html = html.replace('<div id="flash"></div>', '')
        self.respond(html)

    def handle_detail(self, tid):
        tender = TENDERS.get(tid)
        if not tender:
            self.send_error(404, "Tender not found")
            return
        # Build table HTML for table_rows if available
        table_html = ''
        if tender.get('table_rows'):
            table_html += '<h3>Table Data (first 10 rows)</h3><table><tbody>'
            for row in tender['table_rows'][:10]:
                cells = ''.join(f"<td>{c}</td>" for c in row[:10])
                table_html += f"<tr>{cells}</tr>"
            table_html += '</tbody></table>'
        # Render template with individual fields
        html = render_template(
            'detail.html',
            filename=tender['filename'],
            uploaded_at=tender['uploaded_at'],
            emd=tender['emd'] or '—',
            due_date=tender['due_date'] or '—',
            eligibility=tender['eligibility'] or '—',
            summary=tender['summary'] or 'No summary available for this tender.',
            full_text=tender['text']
        )
        html = html.replace('<!--TABLE_ROWS-->', table_html)
        html = html.replace('{{ year }}', str(datetime.utcnow().year))
        self.respond(html)

    def handle_download(self, tid):
        tender = TENDERS.get(tid)
        if not tender:
            self.send_error(404, "Tender not found")
            return
        path = tender['path']
        try:
            with open(path, 'rb') as f:
                data = f.read()
            filename = os.path.basename(path)
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Disposition', f"attachment; filename={filename}")
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            self.send_error(500, f"Error downloading file: {e}")

    def serve_static(self, rel_path: str):
        file_path = os.path.join(STATIC_DIR, rel_path)
        if not os.path.isfile(file_path):
            self.send_error(404, "Static file not found")
            return
        # Determine content type by extension
        ext = os.path.splitext(rel_path)[1].lower()
        content_type = {
            '.css': 'text/css',
            '.js': 'application/javascript',
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.gif': 'image/gif'
        }.get(ext, 'application/octet-stream')
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            self.send_error(500, f"Error serving static file: {e}")

    def handle_upload(self):
        # Parse the multipart form
        ctype, pdict = cgi.parse_header(self.headers.get('Content-Type'))
        if ctype != 'multipart/form-data':
            self.send_error(400, "Invalid form encoding")
            return
        environ = {
            'REQUEST_METHOD': 'POST',
            'CONTENT_TYPE': self.headers.get('Content-Type'),
            'CONTENT_LENGTH': self.headers.get('Content-Length')
        }
        form = cgi.FieldStorage(fp=self.rfile, headers=self.headers, environ=environ)
        files = form['files'] if 'files' in form else None
        # Normalize to list
        if not files:
            self.redirect('/')
            return
        if not isinstance(files, list):
            files = [files]
        count = 0
        for file_item in files:
            if not file_item.filename:
                continue
            filename = os.path.basename(file_item.filename)
            ext = filename.lower().split('.')[-1]
            tender_id = str(uuid.uuid4())
            save_name = tender_id + '_' + filename
            save_path = os.path.join(UPLOAD_DIR, save_name)
            with open(save_path, 'wb') as f:
                f.write(file_item.file.read())
            # Extract data depending on extension
            text = ''
            table_rows = []
            if ext == 'pdf':
                text = extract_text_from_pdf(save_path)
            elif ext == 'docx':
                text = extract_text_from_docx(save_path)
            elif ext in ('xlsx', 'xls'):
                table_rows = parse_xlsx(save_path)
            if not text and table_rows:
                # Flatten first few rows into text for summary and fields
                flat = '\n'.join([', '.join(row) for row in table_rows[:5]])
                text = flat
            summary = simple_summary(text) if text else ''
            fields = extract_fields(text) if text else {'emd': '', 'due_date': '', 'eligibility': ''}
            TENDERS[tender_id] = {
                'id': tender_id,
                'filename': filename,
                'path': save_path,
                'text': text,
                'table_rows': table_rows,
                'summary': summary,
                'emd': fields.get('emd',''),
                'due_date': fields.get('due_date',''),
                'eligibility': fields.get('eligibility',''),
                'uploaded_at': datetime.now().isoformat()
            }
            count += 1
        save_tenders()
        # Redirect back to index
        self.redirect('/?msg=' + f"Uploaded {count} file(s)")

    def redirect(self, url):
        self.send_response(302)
        self.send_header('Location', url)
        self.end_headers()

    def respond(self, html: str):
        # Send HTML content with UTF-8
        encoded = html.encode('utf-8', errors='ignore')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)


def run(server_class=HTTPServer, handler_class=TenderAIHandler, port=8000):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f"TenderAI server running on port {port}...")
    httpd.serve_forever()


if __name__ == '__main__':
    run(port=8000)